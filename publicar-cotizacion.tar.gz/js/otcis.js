/* OTCIS · carrito de cotización compartido por todas las páginas.
   Guarda la lista en localStorage y la envía por WhatsApp o correo. */
(function(){
var WA='56937549608', MAIL='ventas@otcis.cl';
var KEY='otcis-cotizacion', DKEY='otcis-cotizacion-datos';
var COMUNAS=['Quintero','Ventanas','Puchuncaví','Concón','Nogales','Otra comuna'];
var RULES=[['panos',/^toallita/i],['iluminacion',/^foco/i],['electro',/calefactor|hervidor|dispensador de agua/i],['electrico',/pila|limpia contacto|adaptador/i],['insecticidas',/raid|insecticida/i],['cabeza',/^casco/i],['solar',/solar/i],['altura',/arn[eé]s|cola de vida/i],['auditiva',/tap[oó]n|fono|orejera/i],['manos',/guante/i],['respiratoria',/respirador/i],['visual',/antiparra|lente/i],['panos',/pa[ñn]os|toallita/i],['desinfectantes',/desinfectante/i],['dispensadores',/dispensador|bolsas/i],['papel',/papel/i],['adhesivos',/sellante|silicona|espuma|cinta|adhesivo|loctite|trabador/i],['discos',/disco/i]];

var items=[], datos={};
try{items=JSON.parse(localStorage.getItem(KEY)||'[]')}catch(_){}
try{datos=JSON.parse(localStorage.getItem(DKEY)||'{}')}catch(_){}
if(!Array.isArray(items))items=[];

function $(id){return document.getElementById(id)}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function save(){try{localStorage.setItem(KEY,JSON.stringify(items))}catch(_){}}
function saveDatos(){try{localStorage.setItem(DKEY,JSON.stringify(datos))}catch(_){}}
function total(){return items.reduce(function(s,x){return s+x.qty},0)}
function find(name){for(var i=0;i<items.length;i++)if(items[i].name===name)return i;return -1}
function sub(t){for(var i=0;i<RULES.length;i++){if(RULES[i][1].test(t))return RULES[i][0]}return ''}
function nameOf(card){if(!card)return '';if(card.dataset.name)return card.dataset.name;var h=card.querySelector('h3,h4');return h?h.textContent.trim():''}

function add(name,qty,url){
  if(!name)return;
  qty=Math.max(1,parseInt(qty,10)||1);
  var k=find(name);
  if(k>=0)items[k].qty+=qty; else items.push({name:name,qty:qty,url:url||''});
  save(); render(); toast(name,qty);
}

/* ---------- RUT chileno ---------- */
function rutClean(r){return String(r).replace(/[^0-9kK]/g,'').toUpperCase()}
function rutValid(r){
  r=rutClean(r); if(r.length<2)return false;
  var body=r.slice(0,-1), dv=r.slice(-1), s=0, m=2;
  for(var i=body.length-1;i>=0;i--){s+=(+body[i])*m; m=m===7?2:m+1}
  var e=11-(s%11), d=e===11?'0':e===10?'K':String(e);
  return d===dv;
}
function rutFormat(r){
  r=rutClean(r); if(r.length<2)return r;
  var body=r.slice(0,-1), dv=r.slice(-1);
  return body.replace(/\B(?=(\d{3})+(?!\d))/g,'.')+'-'+dv;
}

/* ---------- estilos ---------- */
var css=''+
'.addBtn{background:#E63946;transition:transform .12s,background .12s}'+
'.addBtn:hover{transform:scale(1.08);background:#c92d3a}'+
'.addBtn.added{background:#1f8a5b}'+
'.qbtn{width:30px;height:30px;border-radius:7px;border:1.5px solid #dde1e8;background:#fff;color:#14213A;font-size:16px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;font-family:inherit}'+
'.qbtn:hover{border-color:#14213A}'+
'.qnum{width:44px;height:30px;border:1.5px solid #dde1e8;border-radius:7px;text-align:center;font:700 14px "IBM Plex Sans",sans-serif;color:#14213A;-moz-appearance:textfield}'+
'.qnum::-webkit-outer-spin-button,.qnum::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}'+
'.qpill{position:fixed;bottom:26px;right:100px;height:60px;display:flex;align-items:center;gap:12px;padding:0 22px 0 18px;border:none;border-radius:100px;background:#14213A;color:#fff;font:700 15px "Archivo",sans-serif;cursor:pointer;box-shadow:0 12px 30px -8px rgba(20,33,64,.6);z-index:100}'+
'.qpill .qc{min-width:26px;height:26px;padding:0 7px;border-radius:100px;background:#E63946;display:flex;align-items:center;justify-content:center;font-size:13px}'+
'.qbadge{min-width:20px;height:20px;padding:0 6px;border-radius:100px;background:#fff;color:#E63946;font-size:12px;display:inline-flex;align-items:center;justify-content:center;margin-left:2px}'+
'#qOverlay{position:fixed;inset:0;background:rgba(9,16,33,.45);z-index:150}'+
'#qPanel{position:fixed;top:0;right:0;bottom:0;width:min(440px,100%);background:#fff;z-index:160;display:flex;flex-direction:column;box-shadow:-20px 0 50px -20px rgba(9,16,33,.5);font-family:"IBM Plex Sans",sans-serif;color:#14213A}'+
'#qPanel h2{font:800 20px "Archivo",sans-serif;color:#14213A}'+
'#qPanel .qf{width:100%;border:1.5px solid #dde1e8;border-radius:9px;padding:10px 12px;font:14px "IBM Plex Sans",sans-serif;color:#14213A;background:#fff}'+
'#qPanel .qf.bad{border-color:#E63946;background:#fff6f7}'+
'#qPanel textarea.qf{resize:vertical;min-height:60px}'+
'#qPanel .qrow{display:grid;grid-template-columns:1fr 1fr;gap:8px}'+
'#qPanel .qlbl{font-size:12px;font-weight:600;color:#5a6272;margin:2px 0 -2px}'+
'#qPanel .qerr{font-size:13px;color:#c92d3a;font-weight:600}'+
'#qPanel .qok{font-size:13.5px;line-height:1.5;color:#1f6b47;background:#eaf7f0;border-radius:9px;padding:12px 14px}'+
'.qsend{display:flex;align-items:center;justify-content:center;gap:9px;color:#fff;border:none;font:700 15px "Archivo",sans-serif;padding:14px;border-radius:10px;cursor:pointer;width:100%}'+
'.qsend.wa{background:#25D366}.qsend.wa:hover{background:#1eb858}'+
'.qsend.ml{background:#14213A}.qsend.ml:hover{background:#0f1930}'+
'.qitem{display:flex;align-items:center;gap:10px;padding:13px 0;border-bottom:1px solid #f0f1f4}'+
'.qitem a{color:#14213A}.qitem a:hover{color:#E63946}'+
'#qToast{position:fixed;left:50%;bottom:100px;transform:translateX(-50%) translateY(20px);opacity:0;pointer-events:none;background:#14213A;color:#fff;border-radius:12px;padding:12px 14px 12px 18px;display:flex;align-items:center;gap:14px;font:600 14px "IBM Plex Sans",sans-serif;box-shadow:0 16px 40px -12px rgba(9,16,33,.6);z-index:170;transition:all .2s;max-width:calc(100% - 32px)}'+
'#qToast.on{opacity:1;transform:translateX(-50%);pointer-events:auto}'+
'#qToast button{background:#E63946;color:#fff;border:none;border-radius:8px;padding:8px 12px;font:700 13px "Archivo",sans-serif;cursor:pointer;white-space:nowrap}'+
'.subchip{font-size:12.5px;font-weight:600;padding:8px 15px;border-radius:100px;border:none;cursor:pointer;font-family:inherit;background:#f0f1f4;color:#5a6272}'+
'.subchip.on{background:#14213A;color:#fff}'+
'.addWide{display:flex;align-items:center;justify-content:center;gap:7px;width:100%;background:#E63946;color:#fff;border:none;font:700 13px "Archivo",sans-serif;padding:11px;border-radius:8px;cursor:pointer;transition:background .12s}'+
'.addWide:hover{background:#c92d3a}.addWide.added{background:#1f8a5b}'+
'#qBar{display:none}'+
'@media(max-width:900px){.qpill{right:96px;padding:0 16px 0 14px;font-size:14px}#qPanel .qrow{grid-template-columns:1fr}'+
  'body.q-on{padding-bottom:calc(80px + env(safe-area-inset-bottom))}'+
  'body.q-on #qBar{display:block;position:fixed;left:0;right:0;bottom:0;height:calc(80px + env(safe-area-inset-bottom));background:#fff;border-top:1px solid #e5e8ee;box-shadow:0 -10px 24px -14px rgba(9,16,33,.3);z-index:90}'+
  'body.q-on .qpill{left:14px !important;right:88px !important;bottom:calc(10px + env(safe-area-inset-bottom)) !important;justify-content:center}'+
  'body.q-on .waFloat{bottom:calc(10px + env(safe-area-inset-bottom)) !important;right:14px !important}'+
  '#qToast{bottom:100px}}'+
'@media print{.qpill,#qPanel,#qOverlay,#qToast{display:none !important}}';

var ICON_LIST='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4M12 16h4M8 11h.01M8 16h.01"/></svg>';
var ICON_WA='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>';
var ICON_MAIL='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg>';

function field(id,label,type,ac,ph){
  return '<div style="display:flex;flex-direction:column;gap:6px"><label class="qlbl" for="'+id+'">'+label+'</label><input id="'+id+'" class="qf" type="'+type+'" autocomplete="'+ac+'" placeholder="'+ph+'"></div>';
}

function inject(){
  var st=document.createElement('style'); st.textContent=css; document.head.appendChild(st);
  var wrap=document.createElement('div'); wrap.className='noprint';
  wrap.innerHTML=''+
  '<div id="qBar" aria-hidden="true"></div>'+
  '<button type="button" id="qPill" class="qpill" hidden>'+ICON_LIST+'Mi cotización<span id="qCount" class="qc">0</span></button>'+
  '<div id="qOverlay" data-close hidden></div>'+
  '<aside id="qPanel" role="dialog" aria-modal="true" aria-labelledby="qTitle" hidden>'+
    '<div style="display:flex;align-items:center;justify-content:space-between;padding:20px 24px;border-bottom:1px solid #eceef2">'+
      '<div><h2 id="qTitle">Mi cotización</h2><p id="qLabel" style="font-size:13px;color:#6b7280;margin-top:3px"></p></div>'+
      '<button type="button" data-close aria-label="Cerrar" style="width:38px;height:38px;border-radius:9px;border:1.5px solid #e3e6ec;background:#fff;cursor:pointer;color:#14213A;font-size:20px">×</button>'+
    '</div>'+
    '<div style="flex:1;overflow-y:auto;padding:4px 24px 18px">'+
      '<div id="qList"></div>'+
      '<p id="qEmpty" style="padding:36px 0;text-align:center;font-size:14px;line-height:1.5;color:#6b7280">Aún no agregas productos.<br>Usa el botón <b style="color:#E63946">+</b> en cada producto o "Agregar a cotización" en su ficha.</p>'+
      '<div id="qForm" style="display:flex;flex-direction:column;gap:10px;margin-top:18px">'+
        '<h3 style="font:800 13px Archivo,sans-serif;letter-spacing:.06em;text-transform:uppercase;color:#14213A">Tus datos</h3>'+
        '<div class="qrow">'+field('qNombre','Nombre *','text','name','Juan Pérez')+field('qEmpresa','Empresa','text','organization','Constructora XYZ')+'</div>'+
        '<div class="qrow">'+field('qRut','RUT empresa','text','off','76.123.456-7')+field('qTel','Teléfono','tel','tel','+56 9 1234 5678')+'</div>'+
        field('qMail','Correo','email','email','compras@empresa.cl')+
        '<div style="display:flex;flex-direction:column;gap:6px"><label class="qlbl" for="qComuna">Comuna de entrega</label><select id="qComuna" class="qf"><option value="">Selecciona…</option>'+COMUNAS.map(function(c){return '<option>'+c+'</option>'}).join('')+'</select></div>'+
        '<div style="display:flex;flex-direction:column;gap:6px"><label class="qlbl" for="qNota">Comentarios</label><textarea id="qNota" class="qf" placeholder="Tallas, colores, fecha requerida, dirección…"></textarea></div>'+
      '</div>'+
    '</div>'+
    '<div id="qActions" style="padding:16px 24px 22px;border-top:1px solid #eceef2;display:flex;flex-direction:column;gap:10px">'+
      '<p id="qErr" class="qerr" hidden></p>'+
      '<p id="qOk" class="qok" hidden></p>'+
      '<button type="button" id="qWa" class="qsend wa">'+ICON_WA+'Enviar por WhatsApp</button>'+
      '<button type="button" id="qMailBtn" class="qsend ml">'+ICON_MAIL+'Enviar a ventas@otcis.cl</button>'+
      '<button type="button" id="qClear" style="border:none;background:none;color:#6b7280;font-size:13px;cursor:pointer;padding:4px;font-family:inherit">Vaciar lista</button>'+
    '</div>'+
  '</aside>'+
  '<div id="qToast" role="status" aria-live="polite"><span id="qToastTxt"></span><button type="button" id="qToastBtn">Ver cotización</button></div>';
  document.body.appendChild(wrap);

  ['qNombre','qEmpresa','qRut','qTel','qMail','qComuna','qNota'].forEach(function(id){
    var el=$(id); if(datos[id])el.value=datos[id];
    el.addEventListener('input',function(){datos[id]=el.value; saveDatos(); el.classList.remove('bad'); $('qErr').hidden=true;});
  });
  $('qRut').addEventListener('blur',function(){var v=$('qRut').value.trim(); if(v){$('qRut').value=rutFormat(v); datos.qRut=$('qRut').value; saveDatos();}});
}

/* ---------- render ---------- */
function render(){
  var t=total(), n=items.length;
  $('qPill').hidden=!n; $('qCount').textContent=t;
  $('qLabel').textContent=n?n+(n===1?' producto':' productos')+' · '+t+(t===1?' unidad':' unidades'):'Lista vacía';
  $('qEmpty').hidden=!!n; $('qForm').hidden=!n; $('qActions').hidden=!n;
  $('qList').innerHTML=items.map(function(it,i){
    var nm=it.url?'<a href="'+esc(it.url)+'">'+esc(it.name)+'</a>':esc(it.name);
    return '<div class="qitem"><div style="flex:1;min-width:0;font-size:14px;font-weight:600;line-height:1.35">'+nm+'</div>'+
      '<div style="display:flex;align-items:center;gap:5px;flex:none">'+
      '<button type="button" class="qbtn" data-q="dec" data-i="'+i+'" aria-label="Restar una unidad">−</button>'+
      '<input class="qnum" type="number" min="1" inputmode="numeric" value="'+it.qty+'" data-qi="'+i+'" aria-label="Cantidad de '+esc(it.name)+'">'+
      '<button type="button" class="qbtn" data-q="inc" data-i="'+i+'" aria-label="Sumar una unidad">+</button>'+
      '<button type="button" class="qbtn" data-q="del" data-i="'+i+'" aria-label="Quitar '+esc(it.name)+'" style="border:none;color:#9aa3b5">×</button>'+
      '</div></div>';
  }).join('');
  document.querySelectorAll('[data-quote]').forEach(function(b){
    var bd=b.querySelector('.qbadge');
    if(t){if(!bd){bd=document.createElement('span');bd.className='qbadge';b.appendChild(bd)} bd.textContent=t;}
    else if(bd)bd.remove();
  });
  var names={}; items.forEach(function(x){names[x.name]=x.qty});
  document.querySelectorAll('.prod .addBtn').forEach(function(btn){
    var nm=nameOf(btn.closest('.prod')), on=!!names[nm];
    btn.classList.toggle('added',on); btn.textContent=on?'✓':'+';
    btn.setAttribute('aria-label',on?'En tu cotización · sumar otra unidad':'Agregar a la cotización');
    btn.title=btn.getAttribute('aria-label');
  });
  document.querySelectorAll('.prod .addWide').forEach(function(btn){
    var q=names[nameOf(btn.closest('.prod'))], lb=btn.querySelector('.lbl');
    btn.classList.toggle('added',!!q);
    if(lb)lb.textContent=q?'En tu cotización ('+q+')':'Agregar a cotización';
  });
  document.body.classList.toggle('q-on',n>0);
  document.querySelectorAll('[data-add-quote]').forEach(function(b){
    var q=names[b.dataset.addQuote], lb=b.querySelector('.lbl');
    if(lb)lb.textContent=q?'En tu cotización ('+q+') · agregar más':'Agregar a cotización';
  });
}

var lastFocus=null;
function open(v){
  if(v){lastFocus=document.activeElement; $('qErr').hidden=true; $('qOk').hidden=true;}
  $('qOverlay').hidden=$('qPanel').hidden=!v; document.body.style.overflow=v?'hidden':'';
  if(v){var c=$('qPanel').querySelector('[data-close]'); c&&c.focus();}
  else if(lastFocus&&lastFocus.focus)lastFocus.focus();
}

var tt;
function toast(name,qty){
  $('qToastTxt').textContent=(qty>1?qty+' × ':'')+name+' agregado';
  $('qToast').classList.add('on'); clearTimeout(tt);
  tt=setTimeout(function(){$('qToast').classList.remove('on')},3200);
}

/* ---------- envío ---------- */
function check(needContact){
  var err=[], nm=$('qNombre'), rut=$('qRut'), ml=$('qMail'), tel=$('qTel');
  [nm,rut,ml,tel].forEach(function(x){x.classList.remove('bad')});
  if(!nm.value.trim()){err.push('tu nombre');nm.classList.add('bad')}
  if(rut.value.trim()&&!rutValid(rut.value)){err.push('un RUT válido');rut.classList.add('bad')}
  if(ml.value.trim()&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ml.value.trim())){err.push('un correo válido');ml.classList.add('bad')}
  if(needContact&&!ml.value.trim()&&!tel.value.trim()){err.push('un correo o teléfono para responderte');tel.classList.add('bad')}
  if(err.length){$('qErr').textContent='Falta '+err.join(', ')+'.'; $('qErr').hidden=false; $('qPanel').querySelector('.bad').focus(); return false}
  $('qErr').hidden=true; return true;
}
function msg(){
  var v=function(id){return $(id).value.trim()};
  var lines=items.map(function(it){return '• '+it.qty+' x '+it.name}).join('\n');
  var who=[['Nombre',v('qNombre')],['Empresa',v('qEmpresa')],['RUT',v('qRut')],['Teléfono',v('qTel')],['Correo',v('qMail')],['Comuna de entrega',v('qComuna')]]
    .filter(function(x){return x[1]}).map(function(x){return x[0]+': '+x[1]}).join('\n');
  var nota=v('qNota');
  return 'Hola OTCIS, quiero solicitar una cotización:\n\n'+lines+'\n\n'+who+(nota?'\n\nComentarios: '+nota:'')+'\n\nGracias.';
}
/* Abre WhatsApp o el correo con un enlace normal, igual que si el visitante hiciera clic en él. */
function openLink(url,newTab){
  var a=document.createElement('a'); a.href=url;
  if(newTab){a.target='_blank'; a.rel='noopener'}
  document.body.appendChild(a); a.click(); a.remove();
}
/* Envía la cotización a ventas@otcis.cl con FormSubmit, el mismo servicio que usa el formulario de contacto. */
function sendForm(){
  var v=function(id){return $(id).value.trim()}, emp=v('qEmpresa');
  var data=[
    ['_subject','Nueva solicitud de cotización (web · carrito)'+(emp?' · '+emp:'')],
    ['_next',location.origin+'/gracias.html'],
    ['_template','table'],
    ['_honey',''],
    ['Nombre',v('qNombre')],['Empresa',emp],['RUT',v('qRut')],['Teléfono',v('qTel')],['email',v('qMail')],['Comuna de entrega',v('qComuna')],
    ['Productos',items.map(function(it){return it.qty+' x '+it.name}).join('\n')],
    ['Total de unidades',String(total())],
    ['Comentarios',v('qNota')]
  ];
  var f=document.createElement('form'); f.method='POST'; f.action='https://formsubmit.co/'+MAIL; f.style.display='none';
  data.forEach(function(d){if(!d[1]&&d[0].charAt(0)!=='_')return; var i=document.createElement('input'); i.type='hidden'; i.name=d[0]; i.value=d[1]; f.appendChild(i)});
  document.body.appendChild(f);
  items=[]; save();
  f.submit();
}
function sent(via){
  $('qOk').innerHTML='Listo, se abrió '+via+' con tu solicitud. Envía el mensaje y te respondemos en máximo 2 horas hábiles. <button type="button" id="qDone" style="display:block;margin-top:8px;background:none;border:none;padding:0;color:#1f6b47;font:700 13px inherit;text-decoration:underline;cursor:pointer">Ya la envié, vaciar lista</button>';
  $('qOk').hidden=false;
}

/* ---------- eventos ---------- */
document.addEventListener('click',function(e){
  var t=e.target, x;
  if((x=t.closest('.addBtn,.addWide'))){
    e.preventDefault(); var card=x.closest('.prod'), a=card&&card.querySelector('h3 a,h4 a');
    add(nameOf(card),1,a?a.href:''); return;
  }
  if((x=t.closest('[data-add-quote]'))){
    e.preventDefault(); var qi=document.getElementById(x.dataset.qtyInput||'pQty');
    add(x.dataset.addQuote,qi?qi.value:1,location.href.split('#')[0]); if(qi)qi.value=1; return;
  }
  if((x=t.closest('[data-pq]'))){
    var inp=document.getElementById(x.dataset.target||'pQty'); if(!inp)return;
    var val=Math.max(1,(parseInt(inp.value,10)||1)+(x.dataset.pq==='inc'?1:-1)); inp.value=val; return;
  }
  if((x=t.closest('[data-q]'))){
    var i=+x.dataset.i, a2=x.dataset.q; if(!items[i])return;
    if(a2==='inc')items[i].qty++; else if(a2==='dec')items[i].qty=Math.max(1,items[i].qty-1); else items.splice(i,1);
    save(); render(); return;
  }
  if(t.closest('#qPill')||t.closest('#qToastBtn')){$('qToast').classList.remove('on'); open(true); return;}
  if(t.closest('[data-close]')){open(false); return;}
  if((x=t.closest('[data-quote]'))&&items.length){e.preventDefault(); open(true); return;}
  if(t.closest('#qWa')&&items.length){if(!check(false))return; openLink('https://wa.me/'+WA+'?text='+encodeURIComponent(msg()),true); sent('WhatsApp'); return;}
  if(t.closest('#qMailBtn')&&items.length){if(!check(true))return; x=t.closest('#qMailBtn'); x.disabled=true; x.lastChild.textContent='Enviando…'; sendForm(); return;}
  if(t.closest('#qClear')||t.closest('#qDone')){items=[]; save(); render(); open(false); return;}
  if((x=t.closest('[data-sub]'))){filterSub(x.dataset.sub); return;}
});
document.addEventListener('change',function(e){
  var t=e.target;
  if(t.matches&&t.matches('.qnum[data-qi]')){var i=+t.dataset.qi; if(items[i]){items[i].qty=Math.max(1,parseInt(t.value,10)||1); save(); render();}}
});
document.addEventListener('keydown',function(e){
  if(e.key==='Escape'&&!$('qPanel').hidden)open(false);
  if(e.key==='Tab'&&!$('qPanel').hidden){
    var f=[].slice.call($('qPanel').querySelectorAll('a[href],button:not([hidden]),input,select,textarea')).filter(function(el){return el.offsetParent!==null});
    if(!f.length)return; var a=f[0], z=f[f.length-1];
    if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()} else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}
  }
});
window.addEventListener('storage',function(e){if(e.key===KEY){try{items=JSON.parse(e.newValue||'[]')}catch(_){items=[]} render();}});

/* ---------- subcategorías en páginas de categoría ---------- */
function filterSub(s){
  var n=0;
  document.querySelectorAll('.grid-prod .prod').forEach(function(el){
    var show=s==='todos'||sub(nameOf(el))===s; el.style.display=show?'':'none'; if(show)n++;
  });
  document.querySelectorAll('[data-sub]').forEach(function(b){b.classList.toggle('on',b.dataset.sub===s)});
  var c=document.querySelector('.prodCount'); if(c)c.textContent=n;
  var l=document.querySelector('.prodLabel'); if(l)l.textContent=n===1?'producto':'productos';
}

window.OTCIS={sub:sub,refresh:render,add:add};
inject(); render();
})();
